import React from "react";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import {makeStyles} from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(8),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
        height:"1000px",

    },
    signIn: {
        backgroundColor: "#00897b",
        '&:hover': {
            background: "#4db6ac",
        },
        margin: theme.spacing(3, 0, 2),
    },
    signUp: {
        backgroundColor: "#7b1fa2",
        '&:hover': {
            background: "#ab47bc",
        },
    },
    answers:{
        display:"flex",
        flexDirection:"row"
    },
    questions:{
        height:"50%",
        backgroundColor:"gray",
        borderRadius:"5px"
    }
}));

export default function CCForm(){
    const classes = useStyles();

    return(
        <form className={classes.form}>
            <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                id="clubName"
                label="Club Name"
                name="clubName"
                autoComplete="clubName"
                autoFocus
                // value={user.username}
                // onChange={e => setUser({...user, username: e.target.value})}
            />
            <div className={classes.questions}>
                <TextField
                    variant="outlined"
                    margin="normal"
                    required
                    fullWidth
                    id="question1"
                    label="Question 1"
                    name="Question 1"
                    autoComplete="Question 1"
                    // value={user.username}
                    // onChange={e => setUser({...user, username: e.target.value})}
                />
                <div className={classes.answers}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                </div>
                <TextField
                    variant="outlined"
                    margin="normal"
                    required
                    fullWidth
                    id="question1"
                    label="Question 1"
                    name="Question 1"
                    autoComplete="Question 1"
                    // value={user.username}
                    // onChange={e => setUser({...user, username: e.target.value})}
                />
                <div className={classes.answers}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                </div>
                <TextField
                    variant="outlined"
                    margin="normal"
                    required
                    fullWidth
                    id="question1"
                    label="Question 1"
                    name="Question 1"
                    autoComplete="Question 1"
                    // value={user.username}
                    // onChange={e => setUser({...user, username: e.target.value})}
                />
                <div className={classes.answers}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                </div>
                <TextField
                    variant="outlined"
                    margin="normal"
                    required
                    fullWidth
                    id="question1"
                    label="Question 1"
                    name="Question 1"
                    autoComplete="Question 1"
                    // value={user.username}
                    // onChange={e => setUser({...user, username: e.target.value})}
                />
                <div className={classes.answers}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                </div>
                <TextField
                    variant="outlined"
                    margin="normal"
                    required
                    fullWidth
                    id="question1"
                    label="Question 1"
                    name="Question 1"
                    autoComplete="Question 1"
                    // value={user.username}
                    // onChange={e => setUser({...user, username: e.target.value})}
                />
                <div className={classes.answers}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="q1a1"
                        label="Answer"
                        name="q1a1"
                        autoComplete="q1a1"
                        // value={user.username}
                        // onChange={e => setUser({...user, username: e.target.value})}
                    />
                </div>
            </div>

            <Button

                // onClick={postLoginRequest}
                fullWidth
                variant="contained"
                color="primary"
                className={classes.signIn}
            >
                Sign In
            </Button>
            <Button

                fullWidth
                variant="contained"
                color="primary"
                className={classes.signUp}
            >
                Sign Up
            </Button>
        </form>
    )
}